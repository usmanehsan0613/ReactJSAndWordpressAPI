<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
// echo "<div style='border: dotted 2px red;'>".__FILE__."</div>";

?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="language" content="<?php echo get_bloginfo("language"); ?>" />
       
	<?php wp_head(); ?>
        <?php 
            // conditional stylesheets are loaded at 
            // functions.php
            // add_action( 'wp_enqueue_scripts', 'twenty_twenty_one_scripts' );
          

        ?>
</head>

<body class="<?php current_lang() ?> 1-column homepage" <?php language_attributes(); ?>>
<?php wp_body_open(); ?>
 
<!-- for notices -->
<?php get_template_part( 'template-parts/header/notices' ); ?>

<?php get_template_part( 'template-parts/header/site-header' ); ?>

<div id="page" class="site">
        
	

	<div id="content" class="site-content">
		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">
