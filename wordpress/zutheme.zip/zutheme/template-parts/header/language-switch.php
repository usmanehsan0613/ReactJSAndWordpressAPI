<?php
/**
 * Displays the site navigation.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
<div class="lang-setting hidden-sm hidden-xs">
    <ul class="pref-lang">
        <li class="txt en">Set Language..</li>
        <li class="txt ar">اضبط اللغة</li>
        <li>
            <a href="javascript:void(0);" id="setlang-en">English</a>
            <span class="selected fa fa-check" id="tick-en" style="display: inline;">&nbsp;</span>
        </li>
        <li>
            <a class="arabic" href="javascript:void(0);" id="setlang-ar">عربي</a>
            <span class="selected fa fa-check" id="tick-ar">&nbsp;</span>
        </li>
    </ul>
    <span class="fa fa-caret-down down-arrow">&nbsp;</span>
    <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>" hreflang="ar" id="lang-ar" style="display: inline;">عربي</a>
    <a class="btn current-lang" href="<?php echo esc_url( home_url( '/' ) ); ?>" hreflang="en" id="lang-en">Eng</a>
</div>
