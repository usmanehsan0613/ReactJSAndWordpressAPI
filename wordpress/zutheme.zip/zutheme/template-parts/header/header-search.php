<?php
/**
 * Displays the site navigation.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
<div class="search-box-area col-lg-9 col-md-9 hidden-sm hidden-xs">
    <form action="_search/search_result.aspx" class="nav-form" id="cse-search-box" role="search">
            <div class="input-group">                    
                <input name="cx" type="hidden" value="012234024565271723772:ixmiuwhleea">
                <input name="cof" type="hidden" value="FORID:10"> 
                <input name="ie" type="hidden" value="UTF-8">
                <input class="form-control" id="srch-term" name="q" placeholder=" Search..." type="text"> 
                <div class="input-group-btn">
                    <button class="btn btn-default" type="submit">
                        <span class="glyphicon glyphicon-search"></span>&nbsp;</button>
                </div>
            </div>
    </form>
</div>
