<?php
/**
 * Displays the site navigation.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

//echo "<div style='border: dotted 2px red;'>".__FILE__."</div>";

?>

<?php if ( has_nav_menu( 'top_menu' ) ) : ?>
	
		 <!-- mobile buttosn to go here -->
		<?php
                   $menuParameters = array(
                    'theme_location'  => 'top_menu',
                    'container'       => false,
                    'echo'            => false,
                    'items_wrap'      => '%3$s',
                    'depth'           => 0,
                     'walker'         => new top_walkernav()
                  );

                  echo strip_tags(wp_nav_menu( $menuParameters ), '<a>' );
                ?>
	
<?php endif; ?>
