<?php
/**
 * Displays the site navigation.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
// echo "<div style='border: dotted 2px red;'>".__FILE__."</div>";

?>


<?php 
    /// for mutlisite network 
    $_currentBlog = get_current_blog_id();
    
    echo 'Current Blog Id : '.$_currentBlog;
    
    if( $_currentBlog > 1) // not main site
    {
        switch_to_blog( '1' ); 	//switch to the main site
            
            if (is_nav_menu(5))
            { 
                    //make sure that menu exists there
                   
                    
                     wp_nav_menu(
                                        array(
                                                'theme_location'  => 'main_menu',
                                                'menu_class'      => 'collapse navbar-collapse',
                                                'container_class' => 'primary-menu-container',
                                                'items_wrap'      => '<ul id="primary-menu-list" class="nav navbar-nav">%3$s</ul>',
                                                'fallback_cb'     => false,
                                                'walker'  => new walkernav()
                                            
                                        )
                                );
            }
	restore_current_blog();
    
    }
    
?>

<?php if ( has_nav_menu( 'main_menu' ) ) : ?>
	<div class="container">
            <div class="col-lg-12 col-md-12">
                <div class="menu" id="main-menu">
                    <div class="navbar navbar-default navbar-static-top" role="navigation">
                       <div class="container-fluid">
                           
                           <!-- mobile -->
                           <div class="navbar-header"><button class="navbar-toggle" data-target="#mynavbar-content" data-toggle="collapse" type="button"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button><a class="navbar-brand hidden-lg hidden-md" href="javascript:void(0);">Menu</a></div>
                           
                                <?php
                               // https://github.com/wp-bootstrap/WP-Bootstrap-MegaMenu-Navwalker
                               
                                wp_nav_menu(
                                        array(
                                                'theme_location'  => 'main_menu',
                                                'menu_class'      => 'collapse navbar-collapse',
                                                'container_class' => 'primary-menu-container',
                                                'items_wrap'      => '<ul id="primary-menu-list" class="nav navbar-nav">%3$s</ul>',
                                                'fallback_cb'     => false,
                                                'walker'  => new walkernav()
                                            
                                        )
                                );
                                ?>
                        
                           
                       </div>
                        
                    </div>
                </div>
            </div>
        </div>
		 
<?php endif; ?>
