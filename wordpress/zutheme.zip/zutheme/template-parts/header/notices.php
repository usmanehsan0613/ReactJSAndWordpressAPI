<?php
/**
 * Displays the site navigation.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>

<style type="text/css">
.notice{
                background-color: #000;
                color: #fff;
        }
        .notice a{
                color: #fff !important; 
                display: block;
        }
        .notice a:hover{
                color: #fff !important; 
        }
        .notice p{
                font-family: 'zu-semiBold';
                font-weight: bold;
                font-size: 1.0em;
        }
        .notice p.txt{
                border-left: solid 1px #fff;
                padding-left: 10px;
        }
        .notice p.ic{
                 width: 5%;
        }
        .notice p.bell{
                
        }
        .notice .container .cnt{
                padding: 5px;
        }
        .notice .container span.fa{
                font-size: 1.5em;
                margin-top: 5px;
                
        }
        @media only screen and (max-width: 990px) {
           .notice p{
                font-size : 0.75em;
           }
           .notice p.txt{
                        border: none;
           }
           .notice .container span.fa{
                font-size: 1.5em;
           }
           .notice p.bell{
                        
                        width: 5% !important;
                        
                }
                .notice p.ic{
                        width: 100%;
                }
                .notice p.numbers{
                        text-align: right;
                }
        }
-->
</style>
<div class="notice">
<div class="container">
<div class="col-lg-10 col-md-10 col-xs-9 no-margin no-padding cnt">
<p class="pull-left ic bell col-lg-1 col-xs-2 no-margin no-padding">
                                        <span class="fa fa-bell"></span>
                                </p>
<p>                <a href="/main/en/covid-blended-learning/index.aspx "></a></p><a href="/main/en/covid-blended-learning/index.aspx ">
<p class="pull-left txt col-lg-11 col-xs-9 no-margin no-padding">
                        COVID-19 NOTICE: PLEASE CLICK HERE FOR IMPORTANT ZU INFORMATION ON COVID-19 RELATED MATTERS<br>
                    AND OUR HYBRID &amp; REMOTE LEARNING MODELS
                </p>
</a><p><a href="/main/en/covid-blended-learning/index.aspx "></a>
            </p></div>
<div class="col-lg-2 col-md-2 col-xs-3 no-margin no-padding cnt">
<p class="pull-left ic col-lg-1 hidden-xs hidden-sm no-margin no-padding">
                                        <span class="fa fa-phone"></span>
                                </p>
<p class="pull-right txt numbers col-lg-10 col-xs-12 no-margin no-padding">
                                        02-599 3111 <br> 04-402 1111
                                </p>
<p></p></div>
<p></p></div>
</div>