<?php
/**
 * Displays the site header.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

//echo "<div style='border: dotted 2px red;'>".__FILE__."</div>";



?>

<div class="sticky-header col-lg-12 col-md-12 col-xs-12" id="sticky-header">
    <div class="container">
        <div class="top-wrapper col-lg-12 col-md-12 col-xs-12 no-margin no-padding">
            
            <div class="zu-header-logo col-lg-1 col-md-1 col-sm-4 col-xs-4 no-margin no-padding">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="background-image: url(<?php echo get_stylesheet_directory_uri().'/assets/images/logohome.png' ?>)">
                        <img alt="Zayed University - sticky logo" class="img-responsive" 
                             src="<?php echo get_stylesheet_directory_uri().'/assets/images/logohome.png' ?>" />
                    </a>
            </div>
            <div class="zu-header-logo star col-lg-1 col-md-1 col-sm-4 col-xs-4 no-margin no-padding">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="background-image: url(<?php echo get_stylesheet_directory_uri().'/assets/images/4-Star-logo.png' ?>)">
                    <img alt="Zayed University - sticky logo" class="img-responsive" 
                         src="<?php echo get_stylesheet_directory_uri(). '/assets/images/4-Star-logo.png' ?>" />
                </a>
            </div>
            
            
            <div class="col-lg-10 col-md-10 hidden-sm hidden-xs">
                <div class="utilities-icons col-lg-12 col-md-12 col-sm-12 hidden-xs hidden-sm">
                    <a class="btn home" data-placement="bottom" data-toggle="tooltip" 
                       href="<?php echo esc_url( home_url( '/' ) ); ?>" title="" data-original-title="Home">
                        <span class="fa fa-home large"></span> &nbsp;
                    </a>
                    <a class="btn home" data-placement="bottom" data-toggle="tooltip" 
                       href="javascript:void(0);" id="topPersonalization" title="" data-original-title="Personalization">
                        <span class="fa fa-cogs large"></span> &nbsp;
                    </a>
                </div>
                
                <div class="top-links col-lg-12 col-md-12 hidden-sm hidden-xs">
                    <div class="language-switch col-lg-3 col-md-3 col-xs-6 pull-right">
                        <?php get_template_part( 'template-parts/header/header-search' ); ?>
                        <?php get_template_part( 'template-parts/header/language-switch' ); ?>
                    </div>
                    <div class="top-links-itself col-lg-9 col-md-9 col-xs-6 pull-right">
                         <?php get_template_part( 'template-parts/header/top_menu' ); ?>
                    </div>
                </div>
                
            </div>
            
            
            
        </div>
    </div> <!-- close contaner -->
</div>
<div class="header-margin col-lg-12 col-md-12 col-xs-12">&nbsp;</div>
<div class="clear"></div>
<div class="menu-container">
    <?php 
        get_template_part( 'template-parts/header/main_menu' ); 
        restore_current_blog();
    ?>
</div>


