<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
?>

<div class="ourstranghtOuter">
    <div class="container-fluid">
        <div class="row ourstranghtInner home-degrees" id="home-degrees">
            <script type="text/javascript">
// 
            
                    $(window).load(function () {
                       $('#homeDegree-slider').owlCarousel({
                            loop:true,
                            margin:10,
                            nav:true,
                            responsive:{
                                0:{
                                    items:1
                                },
                                600:{
                                    items:3
                                },
                                1000:{
                                    items:5
                                }
                            }
                        })
                    });
                    // ]]>
                    </script>

                    <div class="homeDegree-wrapper col-lg-12 no-margin no-padding">
                        <div class="homeDegree-slider col-lg-12 no-margin no-padding" id="homeDegree-slider-outer">
                            <div class="ele-first col-lg-12 no-margin no-padding" id="homeDegree-slider">
                                
                                 <?php
                                
                                   

                                        $cat_query = null;

                                         $args = array(
                                                'post_type' => 'zu_image_links',
                                                'tax_query' => array(
                                                    array(
                                                    'taxonomy' => 'zu-image-links-category',
                                                    'terms' => array('graduate-programs'),
                                                    'field' => 'slug'
                                                    )
                                                )
                                        );

                                        $cat_query = new WP_Query($args);

                                        if ($cat_query->post_count > 6) {
                                              //echo "Will display the posts n slider";
                                        } 
                                        if ($cat_query->have_posts()) {
                                            echo "<h5>" . $category->name . "</h5>";
                                            
                                            while ($cat_query->have_posts()) 
                                            {
                                                $cat_query->the_post();
                                                
                                                $_postID = get_the_ID();

                                                $meta = get_post_meta($_postID);

                                                //$svg_icon_name = get_post_meta($_postID, 'svg_icon_name');
                                                //$_url = get_post_meta($_postID, 'url');

                                                $_all_meta = get_post_meta($_postID);
                                                
                                                //echo $allPostMeta['svg_icon_name'][0];
                                          ?>
                                            
                                               
                                
                                                <div class="col-lg-2 col-xs-4 col-sm-2 item">
                                                    <div class="oursources">
                                                        <a title="<?php the_title(); ?>" href="<?php echo $_all_meta['url'][0]; ?>">
                                                            <span class="<?php echo $_all_meta['svg_icon_name'][0]; ?>"></span>
                                                            <p>
                                                                <?php the_content(); ?>
                                                            </p>
                                                        </a>
                                                    </div>
                                                </div>
                                
                                 <?php
                                            }
                                            
                                        }
                                        
                                        wp_reset_postdata();
                                     
                                ?>
                               
                                
                               </div>
                                                               