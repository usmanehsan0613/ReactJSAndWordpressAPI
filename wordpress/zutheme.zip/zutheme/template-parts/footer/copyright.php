<?php
/**
 * Displays the footer widget area.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
?>
<div class="container hidden-lg hidden-md">
    <div class="text-center">
        <p>Copyright &copy; Zayed University, United Arab Emirates. All rights reserved</p>
    </div>
</div>


<div class="container no-padding hidden-xs hidden-sm container-footer-copyright-logos">
    <div class="col-lg-12 col-md-12 no-margin no-padding">
        <div class="text-left pull-left col-lg-6 col-md-6 no-margin no-padding">
            <p>Copyright &copy; Zayed University, United Arab Emirates. All rights reserved</p>
        </div>
        <div class="pull-right col-lg-6 col-md-6 no-margin no-padding ohsas copyright-footer-logos">
            <a class="copyright-footer-tag" href="news/2017/January/ehs17.aspx">
                <img alt="Ohsas Logo" class="img-responsive" src="<?php echo get_stylesheet_directory_uri().'/assets/images/ohsas.svg' ?>">
            </a> 
            <a class="copyright-footer-tag" href="news/2017/January/ehs17.aspx">
                <img alt="Ohsas Logo" class="img-responsive" src="<?php echo get_stylesheet_directory_uri().'/assets/images/ohsas2.svg' ?>">
            </a> 
            <a class="pull-right external-link" href="javascript:void(0);">
                <img alt="Mystery shopper" class="img-responsive" src="<?php echo get_stylesheet_directory_uri().'/assets/images/MSlogo.jpg' ?>">
            </a>
        </div>
    </div>
</div>
    