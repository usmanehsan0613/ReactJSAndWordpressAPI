<?php
/**
 * Displays the footer widget area.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
?>
    <div class="text-left">
                             <p>
                                 <text class="date-statement">Page Last upated on</text>
                                 <text class="date-statement"><?php twenty_twenty_one_posted_on(); ?></text>
                                 <text class="desc-statement"> This site is best viewed in 1024x768 screen resolution. | Supports Microsoft Internet Explorer 11.0+, Firefox 40.0+, Safari 7.0+, Google Chrome 40.0+</text>
                             </p>
                         </div>