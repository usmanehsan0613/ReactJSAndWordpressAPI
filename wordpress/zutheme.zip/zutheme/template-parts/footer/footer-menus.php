<?php
/**
 * Displays the footer widget area.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
?>
 <?php if ( has_nav_menu( 'footer_top' ) ) : ?>
        <nav aria-label="<?php esc_attr_e( 'Footer top menu', 'twentytwentyone' ); ?>" class="footer-navigation col-lg-12 col-xs-12">
                     <?php
                        wp_nav_menu(
                            array(
                                    'theme_location' => 'footer_top',
                                    'items_wrap'     => '%3$s',
                                    'container'      => false,
                                    'depth'          => 0,
                                    'link_before'    => '',
                                    'link_after'     => '',
                                    'fallback_cb'    => false,
                                    'walker'        => new T5_Nav_Menu_Walker_Simple()
                            )
                        );
                        ?>
              
        </nav><!-- .footer-navigation -->
<?php endif; ?>