<?php
/**
 * Displays the footer widget area.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

 //if ( is_active_sidebar( 'footer_rss' ) ) : ?>
 
	<div class="footer-block col-lg-6 col-md-6 col-xs-12 rss-feeds">
            <?php //dynamic_sidebar( 'footer_rss' ); ?>
            <script type="text/javascript">
              $( window ).load(function() {
                    // GetRssFeeds('en');
              });
            </script>
            <h5><a href="http://feeds.feedburner.com/ZayedUniversityNews" target="_blank"><span class="fa fa-rss rss-feeds" style="color: #ff6600; ">&nbsp;</span></a>&nbsp;&nbsp;RSS Feeds</h5>
            <ul class="list-group">
                <li class="list-group-item rss-feeds">
                    <span class="date" id="rssdate1"></span>
                    <a href="" name="rsslink1" id="rsslink1"></a>
                    <p id="rssdesc1" name="rssdesc1"></a><p id="ressdesc2" name="rssdesc2"> </p>
                </li>
                 <li class="list-group-item rss-feeds">
                    <span class="date" id="rssdate2"></span>
                    <a href="" name="rsslink2" id="rsslink2"></a>
                    <p id="rssdesc2" name="rssdesc2"></a><p id="ressdesc2" name="rssdesc2"> </p>
                </li>            </ul>
        
        </div><!-- .widget-area -->
        
        
<?php // endif; ?>  
 
<div class="footer-block col-lg-6 col-md-6 col-xs-12">
    <?php if ( is_active_sidebar( 'footer_widget_tweets' ) ) : ?>
            <?php dynamic_sidebar( 'footer_widget_tweets' ); ?>
                <script>
                    // start twitter 
                        !function (d, s, id) { var js, fjs = d.getElementsByTagName(s)[0], p = /^http:/.test(d.location) ? 'http' : 'https'; if (!d.getElementById(id)) { js = d.createElement(s); js.id = id; js.src = p + "://platform.twitter.com/widgets.js"; fjs.parentNode.insertBefore(js, fjs); } }(document, "script", "twitter-wjs");
                    // -- end twitter
                </script>
    <?php endif; ?>
    <?php if ( is_active_sidebar( 'footer_widget_downloads' ) ) : ?>
                <aside class="widget-area">
                    <?php dynamic_sidebar( 'footer_widget_downloads' ); ?>
                </aside><!-- .widget-area -->
        <?php endif; ?>
        <ul class="list-group">
            <li class="list-group-item google-apple" style="float: left; padding: 5px 0px 5px 0px;">
                <a target="_blank" href="https://play.google.com/store/apps/details?id=ae.ac.zu.ZayedU" style="display: block; margin-right: 5px; float: left; " class="external-link imgcontainer">
                        <img alt="android app" src="<?php echo get_stylesheet_directory_uri(). '/assets/images/google.jpg' ?>">
                        <img alt="android app" src="<?php echo get_stylesheet_directory_uri(). '/assets/images/google_hover.jpg' ?>">
                </a>
                <a style="display: block;  float: left; " target="_blank" class="external-link imgcontainer" href="https://itunes.apple.com/ae/app/zayedu/id910777827?mt=8">
                        <img alt="download iOS app" src="<?php echo get_stylesheet_directory_uri(). '/assets/images/apple.jpg' ?>">
                        <img alt="download iOS app" src="<?php echo get_stylesheet_directory_uri(). '/assets/images/apple_hover.jpg' ?>">
                </a>
            </li>
            <li class="list-group-item downloads-addons" style="float: left; padding: 5px 0px 0px 0px;"><text>Download addons&nbsp;&nbsp;</text><a title="download flash player" target="_blank" href="https://get.adobe.com/flashplayer/" style="display: block; margin-right: 10px; float: right; " class="external-link"><img alt="download flash plugin" src="//wwwst.zu.ac.ae/main//files/images/adobe_flash.png"></a><a title="download adobe reader" style="display: block;  margin-right: 5px; float: right; " target="_blank" class="external-link" href="https://get.adobe.com/reader/"><i class="fa fa-file-pdf-o" style="color: #DE5D4F; font-size: 1.75em; ">&nbsp;</i></a><a title="Microsoft Excel" style="display: block; margin-right: 5px;  float: right; " target="_blank" href="https://www.microsoft.com/en-us/download/details.aspx?id=10" class="external-link"><i class="fa fa-file-excel-o" style="font-size: 1.75em; color: #8CCE8F">&nbsp;</i></a><a title="Microsoft Word" style="display: block; margin-right: 5px;  float: right; " target="_blank" href="https://www.microsoft.com/en-us/download/details.aspx?id=9" class="external-link"><i class="fa fa-file-word-o" style="font-size: 1.75em; color: #1DA1F2">&nbsp;</i></a></li>
        </ul>
       <div class="footer-social-links  col-lg-12 col-md-12 hidden-sm hidden-xs">
           <div class="social-grey-bg"><a href="http://www.youtube.com/user/zayeduniversityae" class="social-grey youtube external-link" target="_blank"><span class="fa fa-youtube fa-lg">&nbsp;</span></a></div><div class="social-black-bg"><a href="http://www.facebook.com/ZayedUniveristy" class="social-black facebook external-link" target="_blank"><span class="fa fa-facebook fa-lg">&nbsp;</span></a></div><div class="social-grey-bg"><a href="http://www.twitter.com/zayed_u" class="social-grey twitter external-link" target="_blank"><span class="fa fa-twitter fa-lg">&nbsp;</span></a></div><div class="social-black-bg"><a href="http://www.instagram.com/ZayedU" class="social-black instagram external-link" target="_blank"><span class="fa fa-instagram fa-lg">&nbsp;</span></a></div><div class="social-grey-bg"><a href="https://www.linkedin.com/company/zayed-university" class="social-grey instagram linkedin external-link" target="_blank"><span class="fa fa-linkedin fa-lg">&nbsp;</span></a></div><div class="social-grey-bg"><a href="https://itunes.apple.com/ae/institution/zayed-university/id598316597" class="social-grey twitter itunes external-link" target="_blank"><span class="fa fa-graduation-cap">&nbsp;</span></a></div>
            <div class="embed-responsive iframe-container" style="width: 100%; height: 20%; float: left; padding-bottom: 25%; margin: 0px;">
                <iframe autoscroll="0" frameborder="0" height="100%" scrolling="no" width="100%" src="//www.zu.ac.ae/apps/eclc/newsletter/index.aspx?lang=en-US"></iframe>
            </div>
       </div>
</div><!-- .widget-area -->