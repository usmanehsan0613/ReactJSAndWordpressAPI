<?php
/**
 * Displays the footer widget area.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
?>
 <?php if ( has_nav_menu( 'footer_menu' ) ) : ?>
            <div class="links">
                <?php
                    wp_nav_menu(
                        array(
                                'theme_location' => 'footer_menu',
                                'items_wrap'     => '%3$s',
                                'container'      => '',
                                'depth'          => 0,
                                'link_before'    => '',
                                'link_after'     => '',
                                'fallback_cb'    => false,
                                'walker'        => new Footer_Bottom_Menu_Walker()

                        )
                    );
                ?>
            </div>
      
<?php endif; ?>