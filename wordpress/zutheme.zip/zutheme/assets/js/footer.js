/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var base_url = 'https://www.zu.ac.ae/main/';

// -- Rss feeds -
function GetRssFeeds(lang) {
    if (lang == '') { lang = 'en'; }
    url = base_url + lang + '/_rss/news_json.json';
    console.log(url);
    $.ajax({
        url: url,
        type: 'GET',
        
        success: function (data) {
            //console.log('success');
            txt = data.responseText;
            txt = txt.replace('// <to-strip></to-strip>', '');

            console.log(JSON.parse(txt));
            json_data = JSON.parse(txt);  console.log(json_data);
            var rssHtml = '';
            //$('#rssdate1').text(json_data.news[0].pubDate); $('#rsslink1').attr('href', json_data.news[0].link); $('#rsslink1').text(json_data.news[0].title);
            if (lang == 'en') { more = 'more'; } else if (lang == 'ar') { more = 'المزيد'; }
            try {
                rssHtml = "<p>" + json_data.news[0].pubDate + "&nbsp;<strong>" + json_data.news[0].title + "</strong>" + json_data.news[0].description.substring(0, 60) + "....<a class='view-more' href='" + json_data.news[0].link + "'>" + more + "</a></p>";
                $('#ressfeed1').html(rssHtml);
                rssHtml = "<p>" + json_data.news[1].pubDate + "&nbsp;<strong>" + json_data.news[0].title + "</strong>" + json_data.news[1].description.substring(0, 60) + "....<a class='view-more' href='" + json_data.news[1].link + "'>" + more + "</a></p>";
                $('#ressfeed2').html(rssHtml);
                rssHtml = "<p>" + json_data.news[2].pubDate + "&nbsp;<strong>" + json_data.news[0].title + "</strong>" + json_data.news[2].description.substring(0, 60) + "....<a class='view-more' href='" + json_data.news[2].link + "'>" + more + "</a></p>";
                $('#ressfeed3').html(rssHtml);
            } catch (ex) { console.log(ex); }

            
        },
        error: function (data) {
            console.log('error');
            txt = data.responseText;
            txt = txt.replace('// <to-strip></to-strip>', '');
            json_data = JSON.parse(txt); console.log(json_data);
            if (lang == 'en') { more = 'more'; } else if (lang == 'ar') { more = 'المزيد'; }
            try {
                rssHtml = "<p>" + json_data.news[0].pubDate + "&nbsp;<strong>" + json_data.news[0].title + "</strong>" + json_data.news[0].description.substring(0, 60) + "....<a class='view-more' href='" + json_data.news[0].link + "'>" + more + "</a></p>";
                $('#ressfeed1').html(rssHtml);
                rssHtml = "<p>" + json_data.news[1].pubDate + "&nbsp;<strong>" + json_data.news[0].title + "</strong>" + json_data.news[1].description.substring(0, 60) + "....<a class='view-more' href='" + json_data.news[1].link + "'>" + more + "</a></p>";
                $('#ressfeed2').html(rssHtml);
                rssHtml = "<p>" + json_data.news[2].pubDate + "&nbsp;<strong>" + json_data.news[0].title + "</strong>" + json_data.news[2].description.substring(0, 60) + "....<a class='view-more' href='" + json_data.news[2].link + "'>" + more + "</a></p>";
                $('#ressfeed3').html(rssHtml);
            } catch (ex) { console.log(ex); }

        }
    });

}

// get language form localStorage
// GetRssFeeds('en');

// -- for ajax
  $(document).ready(function(){
        $('.likes').click(function(){
           
            let post_id = $(this).attr('data-post');
            let value = $(this).attr('data-likes');
            let meta = 'likes';
            console.log(zu_ajax_object.ajax_url);
            $.ajax({
                type: 'POST',
                url: zu_ajax_object.ajax_url,
                dataType : 'json',
                data: {
                    action: 'update_open_data_meta',
                    post_id: post_id,
                    meta : meta,
                    value : value ,
                    security : zu_ajax_object.ajaxnonce
                   
                },
                  
                success : function(ght){
                    console.log(ght.code);
                    $('#likes-'+post_id+'').html(ght.likes);
                },
                error : function(err){
                    console.log(err);
                }
            });
        });
    });