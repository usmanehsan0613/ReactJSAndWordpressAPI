<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();

$description = get_the_archive_description();

echo "<div style='border: dotted 2px red;'>".__FILE__."</div>";

?>

<?php if ( have_posts() ) : ?>
<div class="clear">&nbsp;</div>
<div class="counter">
    <a href="">
        total Files
    </a>
    
    <?php 
    
        // count all the posts in categorires
    $_totalfiles = 0; 
    $taxonomy = 'open-data-category';
    $terms = get_terms($taxonomy);
    // echo '<pre>'; print_r($terms);
    foreach($terms as $term):
        $_totalfiles += $term->count;
        echo '<a href="#"> Total of '.$term->count.' in '.$term->slug.'</a>-----------';
    endforeach;
        echo '<a href="#"> Total of '.$_totalfiles.'</a>-----------';
    ?>
    
</div>

<div class="table-responsive">
    <table class="table">
        <thead>
            <th>Title</th>
            <th>Downloads</th>
            <th>Type</th>
            <th>Share</th>
            <th>Comment</th>
            <th>Like</th>
        </thead>
	<?php while ( have_posts() ) : ?>
         <?php
                   the_post();
                    echo $_postID = get_the_ID();
                    $_all_meta = get_post_meta($_postID);
                    // echo '<pre>'; print_r($_all_meta); echo '</pre>';
                    
                 ?>
        <tr>
            <td>
                <?php echo the_title(); ?>
            </td>
            <td>
                <?php echo $_all_meta['downloads'][0]; ?>
            </td>
             <td>
                <?php 
                    $types = unserialize($_all_meta['type'][0]); 
                    foreach($types as $type):
                        echo '<span class="'.$type.'">'.$type.'</span>&nbsp;/'; 
                    endforeach;
                ?>
            </td>
            <td>
                Add this plugin Form ZU
            </td>
            <td>
                <a href="#" class="comment" data-post="<?php echo $_postID; ?>">Comment</a>
            </td>
             <td>
                <a href="javascript:void(0);" class="likes" id="likes-<?php echo $_postID; ?>" data-likes="<?php echo $_all_meta['likes'][0]; ?>" data-post="<?php echo $_postID; ?>"><?php echo $_all_meta['likes'][0]; ?></a>
            </td>
              <?php // get_template_part( 'template-parts/content/content', get_theme_mod( 'display_excerpt_or_full_post', 'excerpt' ) ); ?>
        </tr>
        <tr>
            <td colspan="5"><?php // the_post(); the_title(); ?></td>
        </tr>
        <?php endwhile; ?>

	<?php twenty_twenty_one_the_posts_navigation(); ?>
    </table>
</div>
<script>
  
    </script>
<?php else : ?>
	<?php get_template_part( 'template-parts/content/content-none' ); ?>
<?php endif; ?>

<?php get_footer(); ?>
