<?php
/*
* Template Name: HomePage
*
* @package WordPress
*/

echo "<div style='border: dotted 2px red;'>".__FILE__."</div>";

get_header();


get_template_part( 'template-parts/content/content-home' );

get_footer();

