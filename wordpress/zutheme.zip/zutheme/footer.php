<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
			</main><!-- #main -->
		</div><!-- #primary -->
	</div><!-- #content -->

        <div style="border: dotted 2px red;"><?php echo __FILE__; ?></div>
        
        <div class="row col-lg-12 col-md-12 col-xs-12 no-margin no-padding row-footer-top">
            <div class="container no-padding row-footer-top-container">
                 <div id="nav">
                    <div id="nav_inner">
                        <footer>
                            <div class="footer col-lg-12 col-md-12 col-xs-12">
                                <div class="footer col-lg-6 col-md-6 col-xs-6">
                                    <?php get_template_part( 'template-parts/footer/footer-menus' ); ?>
                                </div>
                                <div class="footer col-lg-6 col-md-6 col-xs-6">
                                    <?php get_template_part( 'template-parts/footer/footer-widgets' ); ?>
                                </div>
                            </div>
                        </footer>
                    </div>
                     
                    <div class="footer col-lg-12 col-md-12 hidden-xs hidden-sm pull-left">
                       <?php echo do_shortcode("[zu_image_links category='government-logos-footer' limit='20' display='footer']"); ?>
                        <div class="clear">&nbsp;</div>
                        <div class="clear">&nbsp;</div>
                    </div>
                     <div class="clear clear-fix-height">&nbsp;</div>
                     <div class="clear clear-fix-height">&nbsp;</div>
                     <div class="row copyright footer-info hidden-xs hidden-sm col-lg-12 col-md-12">
                        <div aria-label="<?php esc_attr_e( 'footer footer_menu menu', 'twentytwentyone' ); ?>" class="container no-padding">
                           <?php get_template_part( 'template-parts/footer/footer-menus-bottom' ); ?>
                            <?php get_template_part( 'template-parts/footer/page-last-updated' ); ?>
                        </div>
                     </div>
                     
                 </div>
            </div>
        </div>
        <div class="copyright col-sm-12 col-xs-12 col-lg-12">
             <?php get_template_part( 'template-parts/footer/copyright' ); ?>
        </div>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
