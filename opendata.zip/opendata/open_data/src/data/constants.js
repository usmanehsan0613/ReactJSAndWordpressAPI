"use strict";

let baseurl = 'http://localhost/zupress/open-data/wp-json/wp/v2/';
let customBase = 'http://localhost/zupress/open-data/wp-json/';

const constants = 
{
    ccustomBase : 'http://localhost/zupress/open-data/wp-json/'  , 
    metaUpdate  : "http://localhost/zupress/open-data/wp-json/zutheme/v1/update-post-meta",
    generalData : "http://localhost/zupress/open-data/wp-json/zutheme/v1/latest-posts/4"
};

const url = "data:url";

export default constants;