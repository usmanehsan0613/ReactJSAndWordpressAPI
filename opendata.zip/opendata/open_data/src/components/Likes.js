'use strict';

import React from 'react';
import { Link } from 'react-router';
import base64 from 'base-64';
import constants  from '../data/constants';

export default class Likes extends React.Component {

  constructor(props){
    super(props);
    this.state = {
      id : props.id,
      likeCount : props.meta_data.likes
    }

    this.handleLikes = this.handleLikes.bind(this);

  }

  handleLikes(e){
    e.preventDefault();
    const id = e.target.id;
    const likecount = e.target.getAttribute('data-likes');

    if(likecount !== null){
      // update likes on server.
      console.warn(constants.metaUpdate);
      console.warn(likecount);

      let username = 'open-data';
      let password = 'open_data';
      
      let headers = new Headers();

      headers.append('Access-Control-Allow-Origin', 'http://localhost:3333');
      headers.append('Access-Control-Allow-Credentials', 'true');

      var formData = new FormData();
      formData.append('postID', 13);
      formData.append('meta_key', 'likes');
      formData.append('meta_value', 11);
      let url = 'http://localhost/zupress/open-data/wp-json/zutheme/v1/update-posts-meta/';
      //url =     'http://localhost/zupress/open-data/wp-json/zutheme/v1/latest-posts/1'

      fetch(url, {
        method: 'POST',
        headers: new Headers({
          "Authorization": "Basic " + base64.encode(username + ":" + password) 
         }),
        body: formData
      })
      .then(res => res.json())
      .then(json => console.log(json))
      }

      /*fetch(url, {
        method: 'POST',
        headers: new Headers({
          "Authorization": "Basic " + base64.encode(username + ":" + password),
          // 'Content-Type': 'application/json',
          "Access-Control-Allow-Origin" : "*",
          "Access-Control-Allow-Credentials" : "true",
          "Access-Control-Allow-Headers": "*",
          "Access-Control-Allow-Methods": "GET,HEAD,PUT,POST,OPTIONS"
         }),
        body: formData
      })
      .then(res => res.json())
      .then(json => console.log(json))
     }*/

    
  }

  render() {
    return (
      <a href="#" id={this.props.id} data-likes={this.props.meta_data.likes} onClick={ this.handleLikes}>Like</a>
    );
  }
}
