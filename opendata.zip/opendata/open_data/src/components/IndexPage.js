'use strict';

import React from 'react';
import Header from './Header'
import Likes from './Likes';
import constants  from '../data/constants';

// http://localhost/zupress/open-data/wp-json/zutheme/v1/latest-posts/4
export default class IndexPage extends React.Component {

  constructor(props){
    super(props);
       this.state = {
        opendatas: [],
        categories: [],
        total_downloads : 0,
        posts : [],
        posts_meta : [],
        isValid : true, 
        dataReceived : false
      }
      this.some = this.some.bind(this);
  }

  fetchData(opendata){
    console.warn('fetchData '); 
    
    this.setState(
      { 
        dataReceived    : true, 
        opendatas       : opendata,
        posts           : opendata.posts,
        posts_meta      : opendata.posts_meta,
        categories      : opendata.category,
        total_downloads : opendata.total_downloads,
      }
      ); 
  }
  
  componentDidMount(){
    console.warn(constants.generalData);
     fetch(constants.generalData).then(res => res.json())
      /*.then(opendata => this.setState((prevState, props) => {
        this.setState({ dataReceived : true,  opendatas : opendata }, ()=> { this.fetchData(opendata) });
      }));*/
      .then( opendata => {
        // console.log( opendata); 
        this.setState(
            { dataReceived    : true,  
              opendatas       : opendata , 
              posts           : opendata.posts,
              posts_meta      : opendata.posts_meta,
              categories      : opendata.categories,
              total_downloads : opendata.total_downloads,
            }, ()=> { this.fetchData(opendata) });
      })  

  }

  componentWillMount(){
    console.error('componentWillMount');
   
  }

   
  some(){
    console.log('some');
    console.log(this.state.dataReceived);
    console.log(this.state.opendatas);
  }

  render() {
    //console.log('this.state.opendatas');
    console.log('render');
    let TpostsMeta = this.state.posts_meta;
    // console.log(TpostsMeta[10].likes);
    const Tposts = [];
    let Tstateposts = this.state.posts;
    
    for (const key in Tstateposts) {
       Tstateposts[key].posts.map( (item, index) => {
        Tposts.push(item);
       })
    }

    
    return (
      
      <div className="home">
         <Header categories={this.state.categories} total={this.state.total_downloads} {...this.state.opendata} />
       
        <a  title="asdf" onClick={this.some}>afsf</a>
        <div className="opendata">
          {(!this.state.dataReceived) ?
            <p>data has not received</p>
          :  
          <div>
            <p>data is recevied and will be shown shrtly. </p>
            
            <table className="table">
              <thead>
                <th>Title</th>
                <th>Downloads</th>
                <th>Type</th>
                <th>Share</th>
                <th>Comment</th>
                <th>Like</th>
              </thead>
              <tbody>
                {Tposts.map( (item, index) => {
                   return(<tr>
                            <td>{item.post_title}</td>
                            <td>{TpostsMeta[item.ID].downloads}</td>
                            <td>Meta files</td>
                            <td>Static share</td>
                            <td>Static Comment</td>
                            <td>{TpostsMeta[item.ID].likes}</td>
                   </tr>) 
                })}
              </tbody>
            </table>
            
         </div>
         }
          
        </div>

        
      </div>
    );
  }
}
