'use strict';

import React from 'react';
import { Link } from 'react-router';

export default class Header extends React.Component {

    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
    }

    myrender( item ){
        return(<section>
                <span>{item.cat_name}</span>
                <span>{item.category_count}</span>
                </section>);
    }

    handleChange(event){
        console.log(event.target.value);
    }

  render() {
    console.warn('header.js');
    //console.log(this.props);
    return (
     <div className="wrapper">
         <h6>Header.js</h6>
         <p>
             Total Files  {this.props.total}
         </p>
         <div>
             {this.props.categories.map( (item, index)=>{
                if(item.cat_name != null){
                    // return(this.myrender(item));    also works
                    
                    return(<p key={index}>
                                <label>{item.cat_name}</label>
                                <label>---TotalDownloads : {item.category_count}</label>
                                <a href={"https://www.zu.ac.ae/" + item.cat_ID}>Download</a>
                            </p>)
                }
              })}
            </div>  
            <h6>Open Data Search</h6>
            <div className="search">

                <input type="text" name="search" id="search" placeholder=" Open Data Keyword" />

                <select name="category" id="category" onChange={this.handleChange}>
                        <option value="">Search By category</option>
                        {this.props.categories.map( (item, index)=>{
                            if(item.cat_name != null){
                                return(<option value={item.cat_ID}>{item.cat_name}</option>)
                            }
                        })}
                </select>


                <select name="year" id="year">
                    <option name="2020">2020</option>
                    <option name="2019">2019</option>
                    <option name="2018">2018</option>
                    <option name="2017">2017</option>
                    <option name="2016">2016</option>
                    <option name="2015">2015</option>
                </select>
            </div>
          <h6>End Header.js</h6>
     </div>
    );
  }
}
