'use strict';

import React from 'react';
import { Link } from 'react-router';
 
export default class Layout extends React.Component {
  render() {
  
    return (
      <div className="app-container">
        <header>
          <Link to="/">
            Opendata header. 
          </Link>
         </header>
         
        <div className="app-content opendata-content">{this.props.children}</div>
        <footer>
          <p>Footer will go here. </p>
        </footer>
      </div>
    );
  }
}
